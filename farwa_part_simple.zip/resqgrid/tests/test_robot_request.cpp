#include <iostream>
#include <string>
#include "core/Types.h"
#include "core/Robot.h"
#include "core/Request.h"
#include "output/Logger.h"
#include "output/Statistics.h"
using namespace std;

int passed = 0;
int failed = 0;

void check(bool ok, string name) {
    if (ok) {
        passed++;
        cout << "PASS  " << name << endl;
    } else {
        failed++;
        cout << "FAIL  " << name << endl;
    }
}

void testTypes() {
    Capability cap;
    check(fromString("GENERAL", cap) && cap == CAP_GENERAL, "read capability");
    check(toString(CAP_FIRE) == "FIRE", "write capability");

    Category cat;
    check(!fromString("GENERAL", cat), "GENERAL is not a request category");

    EventType ev;
    check(fromString("SET_URGENCY", ev) && ev == EV_SET_URGENCY, "read event type");

    RobotState rs;
    check(fromString(toString(RS_RECHARGING), rs) && rs == RS_RECHARGING, "robot state both ways");
}

void testRobot(Logger& log) {
    Robot r;
    r.setup(4, 0, CAP_FIRE, 120, 100);
    check(r.canServe(CAT_FIRE) && !r.canServe(CAT_MEDICAL), "fire robot serves only fire");

    Robot g;
    g.setup(10, 0, CAP_GENERAL, 110, 110);
    check(g.canServe(CAT_MEDICAL) && g.canServe(CAT_SEARCH), "general robot serves all");

    check(r.useBattery(30) && r.battery == 70, "use battery");
    check(!r.useBattery(71) && r.battery == 70, "battery never below zero");
    r.recharge(100);
    check(r.battery == 120 && r.isFull(), "recharge stops at max");

    Robot low;
    low.setup(2, 0, CAP_GENERAL, 60, 12);
    check(low.isLowBattery(30), "12 of 60 is below 30 percent");

    check(r.setState(RS_TRAVELLING, 0, log), "AVAILABLE -> TRAVELLING");
    check(!r.setState(RS_RECHARGING, 1, log), "TRAVELLING -> RECHARGING refused");
    check(r.setState(RS_PERFORMING, 2, log), "TRAVELLING -> PERFORMING");
    check(r.setState(RS_OFFLINE, 3, log), "PERFORMING -> OFFLINE");
    check(!r.setState(RS_TRAVELLING, 4, log), "OFFLINE -> TRAVELLING refused");
    check(r.setState(RS_AVAILABLE, 5, log), "OFFLINE -> AVAILABLE");

    DynamicArray<Robot> fleet;
    Robot withRoute;
    withRoute.setup(1, 0, CAP_MEDICAL, 100, 100);
    withRoute.route.enqueue(5);
    withRoute.route.enqueue(8);
    for (int i = 0; i < 10; i++) {
        fleet.push_back(withRoute);
    }
    fleet[0].route.dequeue();
    check(fleet[0].route.size() == 1 && fleet[9].route.size() == 2, "each robot has its own route");
}

void testRequest(Logger& log) {
    Request q;
    q.setup(1, 3, 0, CAT_MEDICAL, 4, 2);
    check(q.state == RQ_UNREPORTED, "starts unreported");
    check(!q.setState(RQ_ASSIGNED, 0, log), "UNREPORTED -> ASSIGNED refused");
    check(q.setState(RQ_PENDING, 3, log), "UNREPORTED -> PENDING");
    check(q.priorityKey(50) == 197, "priority key 50*4-3");

    q.markUnreachable(4);
    check(!q.shouldRetry(4) && q.shouldRetry(5), "retry only after network changes");
}

void testAssign(Logger& log) {
    Robot robot;
    robot.setup(3, 0, CAP_MEDICAL, 100, 100);
    Request req;
    req.setup(7, 0, 0, CAT_MEDICAL, 5, 2);
    Request fire;
    fire.setup(8, 0, 0, CAT_FIRE, 5, 2);
    fire.setState(RQ_PENDING, 0, log);

    check(!assignRobot(robot, 0, req, 0, 0, log), "cannot assign unreported request");
    req.setState(RQ_PENDING, 0, log);
    check(!assignRobot(robot, 0, fire, 1, 0, log), "wrong capability refused");
    check(assignRobot(robot, 0, req, 0, 0, log), "assign works");
    check(robot.requestIndex == 0 && req.robotIndex == 0, "both sides linked");

    Robot second;
    second.setup(4, 0, CAP_GENERAL, 100, 100);
    check(!assignRobot(second, 1, req, 0, 1, log), "request cannot get a second robot");

    req.setState(RQ_IN_PROGRESS, 3, log);
    req.doWorkStep();
    robot.setState(RS_OFFLINE, 4, log);
    releaseRobot(robot, req, 4, log);
    check(req.state == RQ_PENDING && req.remainingWork == 1, "released request keeps its work");

    check(assignRobot(second, 1, req, 0, 5, log), "another robot takes it");
    req.setState(RQ_IN_PROGRESS, 6, log);
    check(req.doWorkStep(), "last work step");
    completeRequest(second, req, 7, log);
    check(req.state == RQ_COMPLETED && req.responseTime() == 7, "completed with response 7");
    check(!req.setState(RQ_PENDING, 8, log), "completed is final");
}

void testLogger() {
    Logger log;
    log.setScreen(false);
    log.assign(0, 2, 3, "7-5-6", 6);
    check(log.getLine(0) == "t=0 ASSIGN request=2 robot=3 route=7-5-6 cost=6", "log line format");

    DynamicArray<int> ids;
    ids.push_back(2);
    ids.push_back(4);
    ids.push_back(7);
    check(log.makeRoute(ids) == "2-4-7", "route text");
    check(log.lineCount() == 1, "line count");
}

void testStatistics(Logger& log) {
    DynamicArray<Robot> robots;
    DynamicArray<Request> requests;
    int reportTimes[4] = { 0, 0, 2, 5 };
    int doneTimes[4] = { 16, 7, 28, 20 };

    Robot r;
    r.setup(1, 0, CAP_GENERAL, 100, 100);
    robots.push_back(r);

    for (int i = 0; i < 4; i++) {
        Request q;
        q.setup(i + 1, reportTimes[i], 0, CAT_SEARCH, 3, 1);
        requests.push_back(q);
    }
    for (int i = 0; i < 4; i++) {
        requests[i].setState(RQ_PENDING, reportTimes[i], log);
        assignRobot(robots[0], 0, requests[i], i, reportTimes[i], log);
        requests[i].setState(RQ_IN_PROGRESS, doneTimes[i], log);
        completeRequest(robots[0], requests[i], doneTimes[i], log);
    }

    Request stuck;
    stuck.setup(5, 0, 0, CAT_FIRE, 1, 1);
    stuck.setState(RQ_PENDING, 0, log);
    stuck.markUnreachable(0);
    requests.push_back(stuck);

    robots[0].useBattery(20);
    robots[0].addDistance(20);

    Statistics stats;
    robots[0].state = RS_TRAVELLING;
    stats.recordStep(robots);
    stats.recordStep(robots);
    robots[0].state = RS_AVAILABLE;
    stats.recordStep(robots);
    stats.recordStep(robots);

    stats.finish(robots, requests, 28, log);
    check(stats.completed == 4, "4 completed");
    check(stats.failed == 1 && requests[4].failReason == "unreachable", "1 failed as unreachable");
    check(stats.maxResponse == 26, "max response 26");
    check(stats.averageResponse == 16, "average response 16");
    check(stats.utilization == 50, "utilization 50 percent");
    check(stats.totalDistance == 20 && stats.totalBattery == 20, "distance and battery");

    DynamicArray<int> locationIds;
    locationIds.push_back(1);
    cout << endl;
    stats.printFinal(cout);
    stats.printRobots(cout, robots, requests, locationIds);
    stats.printRequests(cout, requests, robots, locationIds);
}

int main() {
    Logger log;
    log.setScreen(false);

    testTypes();
    testRobot(log);
    testRequest(log);
    testAssign(log);
    testLogger();
    testStatistics(log);

    cout << endl << passed << " passed, " << failed << " failed" << endl;
    return 0;
}
