#include <iostream>
#include <string>
#include "containers/DynamicArray.h"
#include "containers/LinkedList.h"
#include "containers/Queue.h"
#include "containers/MergeSort.h"
using namespace std;

int passed = 0;
int failed = 0;

void check(bool ok, string name) {
    if (ok) {
        passed++;
        cout << "PASS  " << name << endl;
    } else {
        failed++;
        cout << "FAIL  " << name << endl;
    }
}

struct Record {
    int time;
    int order;
};

bool earlier(Record a, Record b) {
    return a.time < b.time;
}

bool smaller(int a, int b) {
    return a < b;
}

void testDynamicArray() {
    DynamicArray<int> a;
    check(a.size() == 0, "array starts empty");

    for (int i = 0; i < 10000; i++) {
        a.push_back(i * 3);
    }
    bool ok = true;
    for (int i = 0; i < 10000; i++) {
        if (a[i] != i * 3) {
            ok = false;
        }
    }
    check(a.size() == 10000 && ok, "push 10000 ints and read them back");

    DynamicArray<int> b = a;
    b[0] = -1;
    check(a[0] == 0 && b[0] == -1, "copy is separate from the original");

    DynamicArray<int> c;
    c.push_back(7);
    c = a;
    c[1] = -5;
    check(c.size() == 10000 && a[1] == 3, "assignment makes a separate copy");

    c.clear();
    check(c.size() == 0 && c.isEmpty(), "clear");

    DynamicArray<string> s;
    s.push_back("alpha");
    s.push_back("beta");
    check(s[1] == "beta", "works with string");
}

void testLinkedList() {
    LinkedList<int> list;
    check(list.isEmpty(), "list starts empty");

    list.pushBack(2);
    list.pushBack(3);
    list.pushFront(1);
    check(list.size() == 3 && list.front() == 1, "pushFront and pushBack");

    int expected = 1;
    bool ok = true;
    ListNode<int>* node = list.getHead();
    while (node != nullptr) {
        if (node->value != expected) {
            ok = false;
        }
        expected++;
        node = node->next;
    }
    check(ok, "list order is 1 2 3");

    LinkedList<int> copy = list;
    copy.popFront();
    check(list.size() == 3 && copy.size() == 2, "copy is separate");

    check(list.popFront() == 1, "popFront returns first value");
    list.popFront();
    list.popFront();
    check(list.isEmpty(), "empty after popping all");

    list.pushBack(5);
    check(list.front() == 5 && list.size() == 1, "usable again after being emptied");
}

void testQueue() {
    Queue<int> q;
    for (int i = 1; i <= 5; i++) {
        q.enqueue(i * 10);
    }
    check(q.size() == 5 && q.front() == 10, "enqueue");

    bool ok = true;
    for (int i = 1; i <= 5; i++) {
        if (q.dequeue() != i * 10) {
            ok = false;
        }
    }
    check(ok && q.isEmpty(), "first in, first out");

    q.enqueue(4);
    q.enqueue(7);
    Queue<int> other = q;
    other.dequeue();
    check(q.size() == 2 && other.front() == 7, "copy is separate");
}

void testMergeSort() {
    DynamicArray<int> nums;
    int values[10] = { 9, 4, 7, 1, 8, 2, 2, 6, 0, 5 };
    for (int i = 0; i < 10; i++) {
        nums.push_back(values[i]);
    }
    mergeSort(nums, smaller);
    bool ok = true;
    for (int i = 1; i < nums.size(); i++) {
        if (nums[i - 1] > nums[i]) {
            ok = false;
        }
    }
    check(ok, "sorts numbers");

    DynamicArray<Record> records;
    int times[8] = { 30, 10, 20, 10, 30, 10, 20, 0 };
    for (int i = 0; i < 8; i++) {
        Record r;
        r.time = times[i];
        r.order = i;
        records.push_back(r);
    }
    mergeSort(records, earlier);
    check(records[0].time == 0 && records[7].time == 30, "sorts records by time");
    check(records[1].order == 1 && records[2].order == 3 && records[3].order == 5, "equal times keep file order");

    DynamicArray<int> empty;
    mergeSort(empty, smaller);
    check(empty.size() == 0, "empty array");
}

int main() {
    testDynamicArray();
    testLinkedList();
    testQueue();
    testMergeSort();
    cout << endl << passed << " passed, " << failed << " failed" << endl;
    return 0;
}
