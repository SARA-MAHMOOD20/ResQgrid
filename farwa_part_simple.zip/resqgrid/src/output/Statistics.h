#ifndef STATISTICS_H
#define STATISTICS_H

#include <iostream>
#include <string>
#include <ctime>
#include "../containers/DynamicArray.h"
#include "../core/Robot.h"
#include "../core/Request.h"
#include "Logger.h"
using namespace std;

class Statistics {
public:
    int conflicts;
    int reroutes;
    int batteryRejections;
    int routeSearches;
    int eventsApplied;

    int stepsRun;
    int busyRobotSteps;

    int totalRequests;
    int completed;
    int failed;
    int openAtEnd;
    int reassignments;
    double averageResponse;
    int maxResponse;
    double utilization;
    int totalDistance;
    int totalBattery;
    double runTimeMs;

    Statistics();

    void startTimer();
    void stopTimer();

    void recordStep(DynamicArray<Robot>& robots);
    void finish(DynamicArray<Robot>& robots, DynamicArray<Request>& requests, int endTime, Logger& log);

    void printFinal(ostream& out);
    void printRobots(ostream& out, DynamicArray<Robot>& robots, DynamicArray<Request>& requests, DynamicArray<int>& locationIds);
    void printRequests(ostream& out, DynamicArray<Request>& requests, DynamicArray<Robot>& robots, DynamicArray<int>& locationIds);

private:
    clock_t startClock;
};

#endif
