#ifndef LOGGER_H
#define LOGGER_H

#include <fstream>
#include <string>
#include "../core/Types.h"
#include "../containers/DynamicArray.h"
using namespace std;

class Logger {
private:
    ofstream file;
    bool fileOpen;
    bool showOnScreen;
    DynamicArray<string> lines;

public:
    Logger();
    ~Logger();

    bool openFile(string path);
    void closeFile();
    bool hasFile();
    ofstream& getFile();
    void setScreen(bool on);

    void writeLine(string text);
    void write(int time, string type, string details);

    void assign(int time, int requestId, int robotId, string route, int cost);
    void reject(int time, int requestId, int robotId, string reason, int need, int have);
    void robotState(int time, int robotId, RobotState from, RobotState to);
    void requestState(int time, int requestId, RequestState from, RequestState to);
    void event(int time, string text);
    void move(int time, int robotId, int fromId, int toId, int battery);
    void reroute(int time, int robotId, string text);
    void complete(int time, int requestId, int robotId, int responseTime);
    void fail(int time, int requestId, string reason);
    void warning(int time, string text);
    void invalid(int time, string text);

    string makeRoute(DynamicArray<int>& locationIds);

    int lineCount();
    string getLine(int index);
};

#endif
