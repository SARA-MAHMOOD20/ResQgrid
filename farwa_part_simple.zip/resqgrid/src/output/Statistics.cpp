#include "Statistics.h"

Statistics::Statistics() {
    conflicts = 0;
    reroutes = 0;
    batteryRejections = 0;
    routeSearches = 0;
    eventsApplied = 0;

    stepsRun = 0;
    busyRobotSteps = 0;

    totalRequests = 0;
    completed = 0;
    failed = 0;
    openAtEnd = 0;
    reassignments = 0;
    averageResponse = 0;
    maxResponse = 0;
    utilization = 0;
    totalDistance = 0;
    totalBattery = 0;
    runTimeMs = 0;
    startClock = 0;
}

void Statistics::startTimer() {
    startClock = clock();
}

void Statistics::stopTimer() {
    clock_t endClock = clock();
    runTimeMs = (endClock - startClock) * 1000.0 / CLOCKS_PER_SEC;
}

void Statistics::recordStep(DynamicArray<Robot>& robots) {
    stepsRun++;
    for (int i = 0; i < robots.size(); i++) {
        if (robots[i].isBusy()) {
            robots[i].busySteps++;
            busyRobotSteps++;
        }
    }
}

void Statistics::finish(DynamicArray<Robot>& robots, DynamicArray<Request>& requests, int endTime, Logger& log) {
    openAtEnd = 0;
    for (int i = 0; i < requests.size(); i++) {
        if (requests[i].isFinished()) {
            continue;
        }
        openAtEnd++;

        if (requests[i].state == RQ_UNREPORTED) {
            requests[i].failReason = "not_reported";
        } else if (requests[i].state == RQ_ASSIGNED || requests[i].state == RQ_IN_PROGRESS) {
            requests[i].failReason = "unfinished";
        } else if (requests[i].unreachable) {
            requests[i].failReason = "unreachable";
        } else {
            requests[i].failReason = "not_served";
        }

        if (requests[i].robotIndex != -1) {
            robots[requests[i].robotIndex].requestIndex = -1;
            requests[i].robotIndex = -1;
        }
        requests[i].setState(RQ_FAILED, endTime, log);
        log.fail(endTime, requests[i].id, requests[i].failReason);
    }

    totalRequests = requests.size();
    completed = 0;
    failed = 0;
    reassignments = 0;
    maxResponse = 0;
    int responseSum = 0;

    for (int i = 0; i < requests.size(); i++) {
        reassignments = reassignments + requests[i].timesReleased;
        if (requests[i].state == RQ_COMPLETED) {
            completed++;
            int response = requests[i].responseTime();
            responseSum = responseSum + response;
            if (response > maxResponse) {
                maxResponse = response;
            }
        } else {
            failed++;
        }
    }

    averageResponse = 0;
    if (completed > 0) {
        averageResponse = (double)responseSum / completed;
    }

    totalDistance = 0;
    totalBattery = 0;
    for (int i = 0; i < robots.size(); i++) {
        totalDistance = totalDistance + robots[i].totalDistance;
        totalBattery = totalBattery + robots[i].totalBatteryUsed;
    }

    utilization = 0;
    int possibleSteps = robots.size() * stepsRun;
    if (possibleSteps > 0) {
        utilization = 100.0 * busyRobotSteps / possibleSteps;
    }
}

void Statistics::printFinal(ostream& out) {
    out << "========== FINAL STATISTICS ==========" << endl;
    out << "steps run:            " << stepsRun << endl;
    out << "total requests:       " << totalRequests << endl;
    out << "completed:            " << completed << endl;
    out << "failed:               " << failed << endl;
    out << "open at end:          " << openAtEnd << endl;
    out << "average response:     " << averageResponse << endl;
    out << "max response:         " << maxResponse << endl;
    out << "robot utilization %:  " << utilization << endl;
    out << "total distance:       " << totalDistance << endl;
    out << "total battery used:   " << totalBattery << endl;
    out << "conflicts:            " << conflicts << endl;
    out << "reassignments:        " << reassignments << endl;
    out << "reroutes:             " << reroutes << endl;
    out << "battery rejections:   " << batteryRejections << endl;
    out << "route searches:       " << routeSearches << endl;
    out << "events applied:       " << eventsApplied << endl;
    out << "execution time (ms):  " << runTimeMs << endl;
    out << "======================================" << endl;
}

void Statistics::printRobots(ostream& out, DynamicArray<Robot>& robots, DynamicArray<Request>& requests, DynamicArray<int>& locationIds) {
    out << "----- ROBOTS -----" << endl;
    for (int i = 0; i < robots.size(); i++) {
        Robot& r = robots[i];
        out << "robot " << r.id;
        out << "  " << toString(r.capability);
        out << "  " << toString(r.state);
        out << "  at=" << locationIds[r.location];
        if (r.isOnRoad()) {
            out << "->" << locationIds[r.nextLocation];
        }
        out << "  battery=" << r.battery << "/" << r.maxBattery;
        if (r.requestIndex != -1) {
            out << "  request=" << requests[r.requestIndex].id;
        }
        if (r.targetLocation != -1) {
            out << "  target=" << locationIds[r.targetLocation];
        }
        out << "  done=" << r.jobsCompleted << endl;
    }
}

void Statistics::printRequests(ostream& out, DynamicArray<Request>& requests, DynamicArray<Robot>& robots, DynamicArray<int>& locationIds) {
    out << "----- REQUESTS -----" << endl;
    for (int s = RQ_PENDING; s <= RQ_FAILED; s++) {
        out << REQUEST_STATE_NAMES[s] << ":" << endl;
        for (int i = 0; i < requests.size(); i++) {
            Request& q = requests[i];
            if (q.state != s) {
                continue;
            }
            out << "   request " << q.id;
            out << "  " << toString(q.category);
            out << "  urgency=" << q.urgency;
            out << "  at=" << locationIds[q.location];
            out << "  reported=" << q.reportTime;
            if (q.robotIndex != -1) {
                out << "  robot=" << robots[q.robotIndex].id;
            }
            if (q.state == RQ_IN_PROGRESS) {
                out << "  work left=" << q.remainingWork;
            }
            if (q.state == RQ_COMPLETED) {
                out << "  response=" << q.responseTime();
            }
            if (q.state == RQ_FAILED) {
                out << "  reason=" << q.failReason;
            }
            if (q.state == RQ_PENDING && q.unreachable) {
                out << "  (unreachable)";
            }
            out << endl;
        }
    }
}
