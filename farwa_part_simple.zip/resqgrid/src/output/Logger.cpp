#include "Logger.h"
#include <iostream>
using namespace std;

Logger::Logger() {
    fileOpen = false;
    showOnScreen = true;
}

Logger::~Logger() {
    closeFile();
}

bool Logger::openFile(string path) {
    closeFile();
    file.open(path);
    fileOpen = file.is_open();
    return fileOpen;
}

void Logger::closeFile() {
    if (fileOpen) {
        file.close();
        fileOpen = false;
    }
}

bool Logger::hasFile() {
    return fileOpen;
}

ofstream& Logger::getFile() {
    return file;
}

void Logger::setScreen(bool on) {
    showOnScreen = on;
}

void Logger::writeLine(string text) {
    if (showOnScreen) {
        cout << text << endl;
    }
    if (fileOpen) {
        file << text << endl;
    }
    lines.push_back(text);
}

void Logger::write(int time, string type, string details) {
    writeLine("t=" + to_string(time) + " " + type + " " + details);
}

void Logger::assign(int time, int requestId, int robotId, string route, int cost) {
    write(time, "ASSIGN", "request=" + to_string(requestId) + " robot=" + to_string(robotId) + " route=" + route + " cost=" + to_string(cost));
}

void Logger::reject(int time, int requestId, int robotId, string reason, int need, int have) {
    write(time, "REJECT", "request=" + to_string(requestId) + " robot=" + to_string(robotId) + " reason=" + reason + " need=" + to_string(need) + " have=" + to_string(have));
}

void Logger::robotState(int time, int robotId, RobotState from, RobotState to) {
    write(time, "STATE", "robot=" + to_string(robotId) + " " + toString(from) + "->" + toString(to));
}

void Logger::requestState(int time, int requestId, RequestState from, RequestState to) {
    write(time, "REQUEST", "request=" + to_string(requestId) + " " + toString(from) + "->" + toString(to));
}

void Logger::event(int time, string text) {
    write(time, "EVENT", text);
}

void Logger::move(int time, int robotId, int fromId, int toId, int battery) {
    write(time, "MOVE", "robot=" + to_string(robotId) + " from=" + to_string(fromId) + " to=" + to_string(toId) + " battery=" + to_string(battery));
}

void Logger::reroute(int time, int robotId, string text) {
    write(time, "REROUTE", "robot=" + to_string(robotId) + " " + text);
}

void Logger::complete(int time, int requestId, int robotId, int responseTime) {
    write(time, "COMPLETE", "request=" + to_string(requestId) + " robot=" + to_string(robotId) + " response=" + to_string(responseTime));
}

void Logger::fail(int time, int requestId, string reason) {
    write(time, "FAIL", "request=" + to_string(requestId) + " reason=" + reason);
}

void Logger::warning(int time, string text) {
    write(time, "WARNING", text);
}

void Logger::invalid(int time, string text) {
    write(time, "INVALID", text);
}

string Logger::makeRoute(DynamicArray<int>& locationIds) {
    string route = "";
    for (int i = 0; i < locationIds.size(); i++) {
        if (i > 0) {
            route = route + "-";
        }
        route = route + to_string(locationIds[i]);
    }
    return route;
}

int Logger::lineCount() {
    return lines.size();
}

string Logger::getLine(int index) {
    return lines[index];
}
