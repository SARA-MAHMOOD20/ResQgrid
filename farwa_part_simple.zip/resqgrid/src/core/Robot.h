#ifndef ROBOT_H
#define ROBOT_H

#include "Types.h"
#include "../containers/Queue.h"
#include "../output/Logger.h"

class Robot {
public:
    int id;
    Capability capability;
    int maxBattery;
    int battery;
    RobotState state;
    int requestIndex;

    int location;
    int roadConnection;
    int nextLocation;
    int roadProgress;

    Queue<int> route;
    int targetLocation;

    int totalDistance;
    int totalBatteryUsed;
    int busySteps;
    int jobsCompleted;

    Robot();
    void setup(int robotId, int startLocation, Capability cap, int maxBat, int startBat);

    bool canServe(Category category);
    bool isOnRoad();
    bool isMoving();
    bool isFree();
    bool isBusy();
    bool isFull();
    bool isLowBattery(int percent);

    bool useBattery(int amount);
    void recharge(int amount);
    void addDistance(int units);

    bool canChangeTo(RobotState newState);
    bool setState(RobotState newState, int time, Logger& log);

    void clearRoute();
};

#endif
