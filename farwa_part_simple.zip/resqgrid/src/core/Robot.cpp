#include "Robot.h"

Robot::Robot() {
    setup(-1, -1, CAP_GENERAL, 0, 0);
}

void Robot::setup(int robotId, int startLocation, Capability cap, int maxBat, int startBat) {
    id = robotId;
    capability = cap;
    maxBattery = maxBat;
    battery = startBat;
    state = RS_AVAILABLE;
    requestIndex = -1;

    location = startLocation;
    roadConnection = -1;
    nextLocation = -1;
    roadProgress = 0;

    route.clear();
    targetLocation = -1;

    totalDistance = 0;
    totalBatteryUsed = 0;
    busySteps = 0;
    jobsCompleted = 0;
}

bool Robot::canServe(Category category) {
    if (capability == CAP_GENERAL) {
        return true;
    }
    if (capability == CAP_MEDICAL && category == CAT_MEDICAL) return true;
    if (capability == CAP_FIRE && category == CAT_FIRE) return true;
    if (capability == CAP_SUPPLY && category == CAT_SUPPLY) return true;
    if (capability == CAP_SEARCH && category == CAT_SEARCH) return true;
    return false;
}

bool Robot::isOnRoad() {
    return roadConnection != -1;
}

bool Robot::isMoving() {
    return state == RS_TRAVELLING || state == RS_RETURNING;
}

bool Robot::isFree() {
    return state == RS_AVAILABLE && requestIndex == -1;
}

bool Robot::isBusy() {
    return state == RS_TRAVELLING || state == RS_PERFORMING;
}

bool Robot::isFull() {
    return battery >= maxBattery;
}

bool Robot::isLowBattery(int percent) {
    int limit = maxBattery * percent / 100;
    return battery < limit;
}

bool Robot::useBattery(int amount) {
    if (amount < 0 || amount > battery) {
        return false;
    }
    battery = battery - amount;
    totalBatteryUsed = totalBatteryUsed + amount;
    return true;
}

void Robot::recharge(int amount) {
    battery = battery + amount;
    if (battery > maxBattery) {
        battery = maxBattery;
    }
}

void Robot::addDistance(int units) {
    totalDistance = totalDistance + units;
}

bool Robot::canChangeTo(RobotState newState) {
    if (newState == state) {
        return false;
    }
    if (newState == RS_OFFLINE) {
        return true;
    }
    if (state == RS_AVAILABLE) {
        return true;
    }
    if (state == RS_TRAVELLING) {
        return newState == RS_PERFORMING || newState == RS_AVAILABLE || newState == RS_RETURNING;
    }
    if (state == RS_PERFORMING) {
        return newState == RS_AVAILABLE;
    }
    if (state == RS_RETURNING) {
        return newState == RS_RECHARGING || newState == RS_AVAILABLE;
    }
    if (state == RS_RECHARGING) {
        return newState == RS_AVAILABLE || newState == RS_RETURNING;
    }
    if (state == RS_OFFLINE) {
        return newState == RS_AVAILABLE;
    }
    return false;
}

bool Robot::setState(RobotState newState, int time, Logger& log) {
    if (!canChangeTo(newState)) {
        log.invalid(time, "robot=" + to_string(id) + " " + toString(state) + "->" + toString(newState));
        return false;
    }
    log.robotState(time, id, state, newState);
    state = newState;
    return true;
}

void Robot::clearRoute() {
    route.clear();
    targetLocation = -1;
}
