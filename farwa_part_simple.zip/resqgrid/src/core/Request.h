#ifndef REQUEST_H
#define REQUEST_H

#include "Types.h"
#include "Robot.h"
#include "../output/Logger.h"

class Request {
public:
    int id;
    int reportTime;
    int location;
    Category category;
    int urgency;
    int duration;

    RequestState state;
    int remainingWork;
    int robotIndex;

    bool unreachable;
    int checkedVersion;

    int firstAssignTime;
    int finishTime;
    int timesReleased;
    string failReason;

    Request();
    void setup(int requestId, int reportT, int locationIndex, Category cat, int urg, int dur);

    bool isFinished();
    bool shouldRetry(int networkVersion);
    void markUnreachable(int networkVersion);
    int responseTime();
    int priorityKey(int agingInterval);
    bool doWorkStep();

    bool canChangeTo(RequestState newState);
    bool setState(RequestState newState, int time, Logger& log);
};

bool assignRobot(Robot& robot, int robotIndex, Request& request, int requestIndex, int time, Logger& log);
void releaseRobot(Robot& robot, Request& request, int time, Logger& log);
void completeRequest(Robot& robot, Request& request, int time, Logger& log);

#endif
