#include "Request.h"

Request::Request() {
    setup(-1, 0, -1, CAT_MEDICAL, 1, 1);
}

void Request::setup(int requestId, int reportT, int locationIndex, Category cat, int urg, int dur) {
    id = requestId;
    reportTime = reportT;
    location = locationIndex;
    category = cat;
    urgency = urg;
    duration = dur;

    state = RQ_UNREPORTED;
    remainingWork = dur;
    robotIndex = -1;

    unreachable = false;
    checkedVersion = -1;

    firstAssignTime = -1;
    finishTime = -1;
    timesReleased = 0;
    failReason = "";
}

bool Request::isFinished() {
    return state == RQ_COMPLETED || state == RQ_FAILED;
}

bool Request::shouldRetry(int networkVersion) {
    if (!unreachable) {
        return true;
    }
    return networkVersion != checkedVersion;
}

void Request::markUnreachable(int networkVersion) {
    unreachable = true;
    checkedVersion = networkVersion;
}

int Request::responseTime() {
    if (state != RQ_COMPLETED) {
        return -1;
    }
    return finishTime - reportTime;
}

int Request::priorityKey(int agingInterval) {
    return agingInterval * urgency - reportTime;
}

bool Request::doWorkStep() {
    if (remainingWork > 0) {
        remainingWork--;
    }
    return remainingWork == 0;
}

bool Request::canChangeTo(RequestState newState) {
    if (state == RQ_COMPLETED || state == RQ_FAILED) {
        return false;
    }
    if (newState == RQ_FAILED) {
        return true;
    }
    if (state == RQ_UNREPORTED) {
        return newState == RQ_PENDING;
    }
    if (state == RQ_PENDING) {
        return newState == RQ_ASSIGNED;
    }
    if (state == RQ_ASSIGNED) {
        return newState == RQ_IN_PROGRESS || newState == RQ_PENDING;
    }
    if (state == RQ_IN_PROGRESS) {
        return newState == RQ_COMPLETED || newState == RQ_PENDING;
    }
    return false;
}

bool Request::setState(RequestState newState, int time, Logger& log) {
    if (!canChangeTo(newState)) {
        log.invalid(time, "request=" + to_string(id) + " " + toString(state) + "->" + toString(newState));
        return false;
    }
    log.requestState(time, id, state, newState);
    state = newState;
    if (newState == RQ_COMPLETED || newState == RQ_FAILED) {
        finishTime = time;
    }
    return true;
}

bool assignRobot(Robot& robot, int robotIndex, Request& request, int requestIndex, int time, Logger& log) {
    if (!robot.isFree()) {
        log.invalid(time, "robot=" + to_string(robot.id) + " is not free");
        return false;
    }
    if (request.state != RQ_PENDING) {
        log.invalid(time, "request=" + to_string(request.id) + " is not pending");
        return false;
    }
    if (!robot.canServe(request.category)) {
        log.invalid(time, "robot=" + to_string(robot.id) + " cannot serve " + toString(request.category));
        return false;
    }

    request.setState(RQ_ASSIGNED, time, log);
    request.robotIndex = robotIndex;
    request.unreachable = false;
    robot.requestIndex = requestIndex;
    if (request.firstAssignTime == -1) {
        request.firstAssignTime = time;
    }
    return true;
}

void releaseRobot(Robot& robot, Request& request, int time, Logger& log) {
    if (!request.isFinished()) {
        request.setState(RQ_PENDING, time, log);
        request.timesReleased++;
    }
    request.robotIndex = -1;
    robot.requestIndex = -1;
    robot.clearRoute();
}

void completeRequest(Robot& robot, Request& request, int time, Logger& log) {
    request.setState(RQ_COMPLETED, time, log);
    log.complete(time, request.id, robot.id, request.responseTime());
    request.robotIndex = -1;
    robot.requestIndex = -1;
    robot.jobsCompleted++;
    robot.clearRoute();
}
