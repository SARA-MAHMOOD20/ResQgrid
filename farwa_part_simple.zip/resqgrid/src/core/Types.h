#ifndef TYPES_H
#define TYPES_H

#include <string>
using namespace std;

enum LocationType { LOC_JUNCTION, LOC_BUILDING, LOC_HOSPITAL, LOC_DEPOT, LOC_CHARGING, LOC_COMMAND };
enum ConnStatus { CONN_OPEN, CONN_BLOCKED };
enum Capability { CAP_MEDICAL, CAP_FIRE, CAP_SUPPLY, CAP_SEARCH, CAP_GENERAL };
enum Category { CAT_MEDICAL, CAT_FIRE, CAT_SUPPLY, CAT_SEARCH };
enum RobotState { RS_AVAILABLE, RS_TRAVELLING, RS_PERFORMING, RS_RETURNING, RS_RECHARGING, RS_OFFLINE };
enum RequestState { RQ_UNREPORTED, RQ_PENDING, RQ_ASSIGNED, RQ_IN_PROGRESS, RQ_COMPLETED, RQ_FAILED };
enum EventType { EV_BLOCK, EV_UNBLOCK, EV_STATION_DOWN, EV_STATION_UP, EV_SET_URGENCY, EV_ROBOT_OFFLINE, EV_ROBOT_ONLINE };

const string LOCATION_NAMES[6] = { "JUNCTION", "BUILDING", "HOSPITAL", "DEPOT", "CHARGING", "COMMAND" };
const string STATUS_NAMES[2] = { "OPEN", "BLOCKED" };
const string CAPABILITY_NAMES[5] = { "MEDICAL", "FIRE", "SUPPLY", "SEARCH", "GENERAL" };
const string CATEGORY_NAMES[4] = { "MEDICAL", "FIRE", "SUPPLY", "SEARCH" };
const string ROBOT_STATE_NAMES[6] = { "AVAILABLE", "TRAVELLING", "PERFORMING", "RETURNING", "RECHARGING", "OFFLINE" };
const string REQUEST_STATE_NAMES[6] = { "UNREPORTED", "PENDING", "ASSIGNED", "IN_PROGRESS", "COMPLETED", "FAILED" };
const string EVENT_NAMES[7] = { "BLOCK", "UNBLOCK", "STATION_DOWN", "STATION_UP", "SET_URGENCY", "ROBOT_OFFLINE", "ROBOT_ONLINE" };

inline string toString(LocationType value) { return LOCATION_NAMES[value]; }
inline string toString(ConnStatus value) { return STATUS_NAMES[value]; }
inline string toString(Capability value) { return CAPABILITY_NAMES[value]; }
inline string toString(Category value) { return CATEGORY_NAMES[value]; }
inline string toString(RobotState value) { return ROBOT_STATE_NAMES[value]; }
inline string toString(RequestState value) { return REQUEST_STATE_NAMES[value]; }
inline string toString(EventType value) { return EVENT_NAMES[value]; }

inline bool fromString(string text, LocationType& result) {
    for (int i = 0; i < 6; i++) {
        if (LOCATION_NAMES[i] == text) {
            result = (LocationType)i;
            return true;
        }
    }
    return false;
}

inline bool fromString(string text, ConnStatus& result) {
    for (int i = 0; i < 2; i++) {
        if (STATUS_NAMES[i] == text) {
            result = (ConnStatus)i;
            return true;
        }
    }
    return false;
}

inline bool fromString(string text, Capability& result) {
    for (int i = 0; i < 5; i++) {
        if (CAPABILITY_NAMES[i] == text) {
            result = (Capability)i;
            return true;
        }
    }
    return false;
}

inline bool fromString(string text, Category& result) {
    for (int i = 0; i < 4; i++) {
        if (CATEGORY_NAMES[i] == text) {
            result = (Category)i;
            return true;
        }
    }
    return false;
}

inline bool fromString(string text, RobotState& result) {
    for (int i = 0; i < 6; i++) {
        if (ROBOT_STATE_NAMES[i] == text) {
            result = (RobotState)i;
            return true;
        }
    }
    return false;
}

inline bool fromString(string text, RequestState& result) {
    for (int i = 0; i < 6; i++) {
        if (REQUEST_STATE_NAMES[i] == text) {
            result = (RequestState)i;
            return true;
        }
    }
    return false;
}

inline bool fromString(string text, EventType& result) {
    for (int i = 0; i < 7; i++) {
        if (EVENT_NAMES[i] == text) {
            result = (EventType)i;
            return true;
        }
    }
    return false;
}

#endif
