#ifndef LINKED_LIST_H
#define LINKED_LIST_H

template <typename T>
struct ListNode {
    T value;
    ListNode* next;
};

template <typename T>
class LinkedList {
private:
    ListNode<T>* head;
    ListNode<T>* tail;
    int count;

public:
    LinkedList() {
        head = nullptr;
        tail = nullptr;
        count = 0;
    }

    LinkedList(const LinkedList& other) {
        head = nullptr;
        tail = nullptr;
        count = 0;
        ListNode<T>* current = other.head;
        while (current != nullptr) {
            pushBack(current->value);
            current = current->next;
        }
    }

    LinkedList& operator=(const LinkedList& other) {
        if (this == &other) {
            return *this;
        }
        clear();
        ListNode<T>* current = other.head;
        while (current != nullptr) {
            pushBack(current->value);
            current = current->next;
        }
        return *this;
    }

    ~LinkedList() {
        clear();
    }

    void pushFront(T value) {
        ListNode<T>* node = new ListNode<T>;
        node->value = value;
        node->next = head;
        head = node;
        if (tail == nullptr) {
            tail = node;
        }
        count++;
    }

    void pushBack(T value) {
        ListNode<T>* node = new ListNode<T>;
        node->value = value;
        node->next = nullptr;
        if (head == nullptr) {
            head = node;
            tail = node;
        } else {
            tail->next = node;
            tail = node;
        }
        count++;
    }

    T popFront() {
        ListNode<T>* first = head;
        T value = first->value;
        head = head->next;
        if (head == nullptr) {
            tail = nullptr;
        }
        delete first;
        count--;
        return value;
    }

    T front() {
        return head->value;
    }

    void clear() {
        while (head != nullptr) {
            ListNode<T>* nextNode = head->next;
            delete head;
            head = nextNode;
        }
        tail = nullptr;
        count = 0;
    }

    ListNode<T>* getHead() {
        return head;
    }

    int size() {
        return count;
    }

    bool isEmpty() {
        return count == 0;
    }
};

#endif
