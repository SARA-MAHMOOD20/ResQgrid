#ifndef MERGE_SORT_H
#define MERGE_SORT_H

#include "DynamicArray.h"

template <typename T>
void merge(DynamicArray<T>& arr, int left, int mid, int right, bool (*comesFirst)(T, T)) {
    DynamicArray<T> temp;
    int i = left;
    int j = mid + 1;

    while (i <= mid && j <= right) {
        if (comesFirst(arr[j], arr[i])) {
            temp.push_back(arr[j]);
            j++;
        } else {
            temp.push_back(arr[i]);
            i++;
        }
    }
    while (i <= mid) {
        temp.push_back(arr[i]);
        i++;
    }
    while (j <= right) {
        temp.push_back(arr[j]);
        j++;
    }

    for (int k = 0; k < temp.size(); k++) {
        arr[left + k] = temp[k];
    }
}

template <typename T>
void mergeSort(DynamicArray<T>& arr, int left, int right, bool (*comesFirst)(T, T)) {
    if (left >= right) {
        return;
    }
    int mid = (left + right) / 2;
    mergeSort(arr, left, mid, comesFirst);
    mergeSort(arr, mid + 1, right, comesFirst);
    merge(arr, left, mid, right, comesFirst);
}

template <typename T>
void mergeSort(DynamicArray<T>& arr, bool (*comesFirst)(T, T)) {
    mergeSort(arr, 0, arr.size() - 1, comesFirst);
}

#endif
