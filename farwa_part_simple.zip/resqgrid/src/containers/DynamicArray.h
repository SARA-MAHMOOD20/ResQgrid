#ifndef DYNAMIC_ARRAY_H
#define DYNAMIC_ARRAY_H

template <typename T>
class DynamicArray {
private:
    T* items;
    int count;
    int capacity;

    void grow(int newCapacity) {
        T* bigger = new T[newCapacity];
        for (int i = 0; i < count; i++) {
            bigger[i] = items[i];
        }
        delete[] items;
        items = bigger;
        capacity = newCapacity;
    }

public:
    DynamicArray() {
        items = nullptr;
        count = 0;
        capacity = 0;
    }

    DynamicArray(const DynamicArray& other) {
        items = nullptr;
        count = 0;
        capacity = 0;
        for (int i = 0; i < other.count; i++) {
            push_back(other.items[i]);
        }
    }

    DynamicArray& operator=(const DynamicArray& other) {
        if (this == &other) {
            return *this;
        }
        clear();
        for (int i = 0; i < other.count; i++) {
            push_back(other.items[i]);
        }
        return *this;
    }

    ~DynamicArray() {
        delete[] items;
    }

    void push_back(T value) {
        if (count == capacity) {
            if (capacity == 0) {
                grow(4);
            } else {
                grow(capacity * 2);
            }
        }
        items[count] = value;
        count++;
    }

    T& operator[](int index) {
        return items[index];
    }

    void reserve(int n) {
        if (n > capacity) {
            grow(n);
        }
    }

    int size() {
        return count;
    }

    bool isEmpty() {
        return count == 0;
    }

    void clear() {
        count = 0;
    }
};

#endif
