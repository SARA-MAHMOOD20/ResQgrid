#ifndef QUEUE_H
#define QUEUE_H

#include "LinkedList.h"

template <typename T>
class Queue {
private:
    LinkedList<T> list;

public:
    void enqueue(T value) {
        list.pushBack(value);
    }

    T dequeue() {
        return list.popFront();
    }

    T front() {
        return list.front();
    }

    bool isEmpty() {
        return list.isEmpty();
    }

    int size() {
        return list.size();
    }

    void clear() {
        list.clear();
    }

    ListNode<T>* getHead() {
        return list.getHead();
    }
};

#endif
