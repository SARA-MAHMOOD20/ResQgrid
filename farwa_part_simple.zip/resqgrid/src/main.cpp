#include <iostream>
#include <string>
#include "core/World.h"
#include "core/ScenarioLoader.h"
#include "core/Simulation.h"
#include "output/Logger.h"
#include "output/Statistics.h"
using namespace std;

void printUsage() {
    cout << "Usage: resqgrid <scenario file> [--log <file>] [--quiet] [--step] [--gui]" << endl;
}

void runStepByStep(Simulation& sim, World& world, Statistics& stats) {
    DynamicArray<int> locationIds;
    for (int i = 0; i < world.locations.size(); i++) {
        locationIds.push_back(world.locations[i].id);
    }

    cout << "Commands: Enter = next step, r = robots, q = requests, a = run to end, x = stop" << endl;

    while (!sim.isFinished()) {
        cout << "[t=" << sim.getTime() << "] > ";
        string command;
        if (!getline(cin, command)) {
            break;
        }

        if (command == "") {
            sim.step();
        } else if (command == "r") {
            stats.printRobots(cout, world.robots, world.requests, locationIds);
        } else if (command == "q") {
            stats.printRequests(cout, world.requests, world.robots, locationIds);
        } else if (command == "a") {
            sim.runAll();
        } else if (command == "x") {
            break;
        } else {
            cout << "Unknown command" << endl;
        }
    }
    cout << endl;
}

int main(int argc, char* argv[]) {
    string scenarioPath = "";
    string logPath = "";
    bool quiet = false;
    bool stepMode = false;
    bool gui = false;

    for (int i = 1; i < argc; i++) {
        string arg = argv[i];
        if (arg == "--quiet") {
            quiet = true;
        } else if (arg == "--step") {
            stepMode = true;
        } else if (arg == "--gui") {
            gui = true;
        } else if (arg == "--log" && i + 1 < argc) {
            logPath = argv[i + 1];
            i++;
        } else if (arg[0] == '-') {
            cout << "Unknown option: " << arg << endl;
            printUsage();
            return 1;
        } else {
            scenarioPath = arg;
        }
    }

    if (scenarioPath == "") {
        printUsage();
        return 1;
    }

    World world;
    ScenarioLoader loader;
    if (!loader.load(scenarioPath, world)) {
        cout << "The scenario file has errors. The simulation was not started." << endl;
        loader.printErrors(cout);
        return 1;
    }

    cout << "Loaded " << scenarioPath << ": "
         << world.locations.size() << " locations, "
         << world.connections.size() << " connections, "
         << world.robots.size() << " robots, "
         << world.requests.size() << " requests, "
         << world.events.size() << " events" << endl;

    if (gui) {
        cout << "GUI is not available in this build." << endl;
        return 1;
    }

    Logger log;
    log.setScreen(!quiet);
    if (logPath != "") {
        if (!log.openFile(logPath)) {
            cout << "Cannot create log file " << logPath << endl;
            return 1;
        }
    }

    Statistics stats;
    Simulation sim(world, log, stats);

    stats.startTimer();
    if (stepMode) {
        runStepByStep(sim, world, stats);
    } else {
        sim.runAll();
    }
    stats.stopTimer();

    if (!sim.isFinished()) {
        stats.finish(world.robots, world.requests, sim.getTime(), log);
    }

    stats.printFinal(cout);
    if (log.hasFile()) {
        stats.printFinal(log.getFile());
        cout << "Log saved to " << logPath << endl;
    }
    return 0;
}
