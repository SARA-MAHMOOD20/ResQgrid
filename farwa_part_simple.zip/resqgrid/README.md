# ResQGrid – AI Rescue Robots

A disaster-response simulator written in C++. A fleet of rescue robots moves through a city graph, takes rescue requests, and reacts to roads closing, charging stations going down and robots going offline. The program writes a step-by-step record of everything that happens and prints final statistics at the end.

Data Structures Lab, Fall 2026 (DS, AI), NUCES Islamabad.
Group: Sarah Mahmood, Rabia Waqar, Farwa Abid.

---

## 1. Rules we follow in the code

- No STL containers (`vector`, `list`, `map`, `queue`, …) and nothing from `<algorithm>`. All containers are our own, in `src/containers/`.
- Allowed headers: `<iostream>`, `<fstream>`, `<string>` (with `using namespace std;`) and `<ctime>` for measuring run time. SFML is used only by the GUI.
- Every `new` has a matching `delete`. Containers free their memory in their destructors.

---

## 2. Building

### With CMake (builds the program and the tests)
```
mkdir build
cd build
cmake ..
cmake --build .
```

### Console version with g++ only (no CMake, no SFML)
Run this from the project folder:
```
g++ -std=c++17 -Wall -I src src/main.cpp src/core/*.cpp src/output/*.cpp -o resqgrid
```

### Tests
```
g++ -std=c++17 -Wall -I src tests/test_containers.cpp -o test_containers
./test_containers

g++ -std=c++17 -Wall -I src tests/test_robot_request.cpp src/core/Robot.cpp src/core/Request.cpp src/output/Logger.cpp src/output/Statistics.cpp -o test_robot_request
./test_robot_request
```
Each test program prints one `PASS` or `FAIL` line per check. It exits with code 0 when every check passes.

---

## 3. Running

```
resqgrid <scenario file> [--log <file>] [--quiet] [--step] [--gui]
```

| Option         | Meaning |
|----------------|---------|
| `--log <file>` | Also write the simulation record to `<file>`. |
| `--quiet`      | Do not print the record on screen. The final statistics are still printed. Use this for large runs. |
| `--step`       | Run one time step at a time (see below). |
| `--gui`        | Open the SFML window. |

Examples:
```
resqgrid data/scenario_provided.txt
resqgrid data/scenario_provided.txt --log output/provided_log.txt
resqgrid data/scenario_05_stress.txt --log output/stress_log.txt --quiet
resqgrid data/scenario_01_tiny_trace.txt --step
```

### Step mode commands
| Type      | Does |
|-----------|------|
| *Enter*   | Run the next time step. |
| `r`       | Show the robot table: state, location, battery, request, target. |
| `q`       | Show the requests grouped as PENDING / ASSIGNED / IN_PROGRESS / COMPLETED / FAILED. |
| `a`       | Run to the end. |
| `x`       | Stop now and print the statistics. |

If the scenario file has errors, the program lists every error with its line number and does not start the simulation.

---

## 4. Input format

A plain text file. It follows the format of `scenario_provided.txt` from the project specification, which loads without any change.

- Lines that start with `#` and blank lines are ignored.
- Fields are separated by spaces. Names contain no spaces.
- Each section starts with `KEYWORD count` and is followed by exactly `count` records. If the count does not match, the file is invalid.
- The file ends with `END`.

| Section / line | Fields |
|----------------|--------|
| `SCENARIO name` | optional name |
| `PARAM key value` | `max_steps`, `speed`, `battery_per_cost_unit`, `battery_per_work_step`, `recharge_per_step`. We added two optional keys: `aging_interval` (default 50) and `low_battery_percent` (default 30). |
| `LOCATIONS n` | `id name type`, where type is JUNCTION, BUILDING, HOSPITAL, DEPOT, CHARGING or COMMAND |
| `CONNECTIONS n` | `id location_a location_b cost status`, where status is OPEN or BLOCKED. Roads are undirected. |
| `ROBOTS n` | `id start_location capability max_battery initial_battery`, where capability is MEDICAL, FIRE, SUPPLY, SEARCH or GENERAL |
| `REQUESTS n` | `id report_time location category urgency duration_steps`, with urgency from 1 to 5 |
| `EVENTS n` | `time TYPE ref [value]`, where TYPE is BLOCK, UNBLOCK, STATION_DOWN, STATION_UP, SET_URGENCY, ROBOT_OFFLINE or ROBOT_ONLINE |

Records with the same time step are processed in file order.

---

## 5. Output format

### Simulation record
There is one line per change:
```
t=<time step> <TYPE> <details>
```
Example (Scenario 01):
```
t=0 ASSIGN request=2 robot=3 route=7-5-6 cost=6
t=0 REJECT request=1 robot=2 reason=battery need=15 have=12
t=0 STATE robot=2 AVAILABLE->RETURNING
t=4 EVENT BLOCK connection=4 (2-5)
t=4 REROUTE robot=1 on=4 back_to=2 route=2-4-7-5 cost=9
t=7 COMPLETE request=2 robot=3 response=7
```

| TYPE       | Written when | Details |
|------------|--------------|---------|
| `REQUEST`  | a request changes state | `request=ID OLD->NEW` |
| `STATE`    | a robot changes state | `robot=ID OLD->NEW` |
| `ASSIGN`   | a robot is given a request | request, robot, route (location IDs), cost |
| `REJECT`   | a candidate robot is refused | request, robot, reason, need, have |
| `MOVE`     | a robot reaches a location | robot, from, to, battery |
| `REROUTE`  | a robot's route is changed | robot and the new route |
| `EVENT`    | a scenario event is applied | the event |
| `COMPLETE` | a request is finished | request, robot, response time |
| `FAIL`     | a request is marked failed | request, reason (`unreachable`, `not_served`, `unfinished`, `not_reported`) |
| `WARNING`  | a redundant or ignored action | text |
| `INVALID`  | a refused state change | text (should never appear in a correct run) |

Lines are in time order. Within a step, they follow the order of the 7 phases (events, new requests, reroute, assignment, low battery, action, record).

### Final statistics
These are printed at the end and also written at the end of the log file:
steps run, total requests, completed, failed, open at end, average response, max response, robot utilization %, total distance, total battery used, conflicts, reassignments, reroutes, battery rejections, route searches, events applied, execution time (ms).

- **Response time** is completion step minus report time.
- **Utilization** is the share of robot-steps spent TRAVELLING or PERFORMING.

---

## 6. Project layout

```
src/
  main.cpp                 command line, loading, console run
  containers/              DynamicArray, LinkedList, Queue, MergeSort, HashMap, MinHeap, IndexedMaxHeap
  core/                    Types, World, Robot, Request, Environment, Router, ScenarioLoader,
                           EventProcessor, Rerouter, Coordinator, Movement, Simulation
  output/                  Logger, Statistics
  ui/                      GraphLayout, Renderer, UIApp (SFML)
tests/                     test programs (each has its own main)
data/                      scenario files, including scenario_provided.txt
tools/gen_scenario.py      seeded generator for stress scenarios
output/                    logs are written here
```
